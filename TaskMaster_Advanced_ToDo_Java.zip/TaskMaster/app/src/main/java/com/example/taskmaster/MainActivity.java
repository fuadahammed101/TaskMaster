package com.example.taskmaster;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.taskmaster.adapter.TaskAdapter;
import com.example.taskmaster.data.TaskStorage;
import com.example.taskmaster.model.Task;
import com.example.taskmaster.util.DateUtils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity implements TaskAdapter.Callbacks {

    private RecyclerView rv;
    private TaskAdapter adapter;
    private FloatingActionButton fabAdd, fabFilter;
    private final ArrayList<Task> allTasks = new ArrayList<>();
    private List<Task> currentView = new ArrayList<>();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv = findViewById(R.id.recyclerView);
        fabAdd = findViewById(R.id.fabAdd);
        fabFilter = findViewById(R.id.fabFilter);

        adapter = new TaskAdapter(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        rv.setAdapter(adapter);

        // Load tasks
        allTasks.clear();
        allTasks.addAll(TaskStorage.load(this));
        applyShowAll();

        fabAdd.setOnClickListener(v -> showAddDialog());
        fabFilter.setOnClickListener(v -> showFilterSortDialog());
    }

    // region Add Task
    private void showAddDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_add_task, null);
        EditText etName = view.findViewById(R.id.etTaskName);
        Spinner spnCategory = view.findViewById(R.id.spnCategory);
        Spinner spnPriority = view.findViewById(R.id.spnPriority);
        Button btnPickDate = view.findViewById(R.id.btnPickDate);
        Button btnClearDate = view.findViewById(R.id.btnClearDate);

        final long[] selectedDueAt = { nullLong() };

        ArrayAdapter<CharSequence> catAdapter = ArrayAdapter.createFromResource(
                this, R.array.task_categories, android.R.layout.simple_spinner_item);
        catAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCategory.setAdapter(catAdapter);

        ArrayAdapter<CharSequence> prAdapter = ArrayAdapter.createFromResource(
                this, R.array.task_priorities, android.R.layout.simple_spinner_item);
        prAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnPriority.setAdapter(prAdapter);
        spnPriority.setSelection(1); // default Medium

        btnPickDate.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            DatePickerDialog dp = new DatePickerDialog(this, (view1, y, m, d) -> {
                long epoch = DateUtils.toStartOfDayMillis(y, m, d);
                selectedDueAt[0] = epoch;
                btnPickDate.setText(getString(R.string.pick_date_fmt, DateUtils.formatDate(epoch)));
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
            dp.show();
        });

        btnClearDate.setOnClickListener(v -> {
            selectedDueAt[0] = nullLong();
            btnPickDate.setText(R.string.pick_date);
        });

        new AlertDialog.Builder(this)
                .setTitle("Add New Task")
                .setView(view)
                .setPositiveButton("Save", (d, w) -> {
                    String name = etName.getText().toString().trim();
                    if (name.isEmpty()) {
                        Toast.makeText(this, "Task name required", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String category = spnCategory.getSelectedItem().toString();
                    int priority = priorityFromPosition(spnPriority.getSelectedItemPosition());
                    Long due = selectedDueAt[0] == nullLong() ? null : selectedDueAt[0];
                    long id = System.currentTimeMillis();

                    Task t = new Task(id, name, category, false, due, priority);
                    allTasks.add(0, t);
                    TaskStorage.save(this, allTasks);
                    applyShowAll();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    private long nullLong() { return Long.MIN_VALUE; }
    private int priorityFromPosition(int pos) {
        switch (pos) {
            case 0: return 1; // High
            case 1: return 2; // Medium
            case 2: return 3; // Low
            default: return 2;
        }
    }
    // endregion

    // region Filter/Sort
    private void showFilterSortDialog() {
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_filter_sort, null);

        View btnAll = view.findViewById(R.id.btnShowAll);
        View btnOverdue = view.findViewById(R.id.btnOverdue);
        View btnToday = view.findViewById(R.id.btnDueToday);
        View btnTodayNoDue = view.findViewById(R.id.btnTodayNoDue);
        View btnNoDueOnly = view.findViewById(R.id.btnNoDue);

        View btnSortHome = view.findViewById(R.id.btnSortHome);
        View btnSortSchool = view.findViewById(R.id.btnSortSchool);
        View btnSortWork = view.findViewById(R.id.btnSortWork);
        View btnSortPriority = view.findViewById(R.id.btnSortPriority);
        View btnSortDueDate = view.findViewById(R.id.btnSortDueDate);
        View btnSortNewest = view.findViewById(R.id.btnSortNewest);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Filter & Sort")
                .setView(view)
                .create();

        btnAll.setOnClickListener(v -> { applyShowAll(); dialog.dismiss(); });
        btnOverdue.setOnClickListener(v -> { filterOverdue(); dialog.dismiss(); });
        btnToday.setOnClickListener(v -> { filterToday(); dialog.dismiss(); });
        btnTodayNoDue.setOnClickListener(v -> { filterTodayPlusNoDue(); dialog.dismiss(); });
        btnNoDueOnly.setOnClickListener(v -> { filterNoDueOnly(); dialog.dismiss(); });

        btnSortHome.setOnClickListener(v -> { sortByCategory("Home"); dialog.dismiss(); });
        btnSortSchool.setOnClickListener(v -> { sortByCategory("School"); dialog.dismiss(); });
        btnSortWork.setOnClickListener(v -> { sortByCategory("Work"); dialog.dismiss(); });
        btnSortPriority.setOnClickListener(v -> { sortByPriority(); dialog.dismiss(); });
        btnSortDueDate.setOnClickListener(v -> { sortByDueDate(); dialog.dismiss(); });
        btnSortNewest.setOnClickListener(v -> { sortByNewest(); dialog.dismiss(); });

        dialog.show();
    }

    private void applyShowAll() {
        currentView = new ArrayList<>(allTasks);
        adapter.submitList(currentView);
    }

    private void filterOverdue() {
        List<Task> out = new ArrayList<>();
        for (Task t : allTasks) {
            if (DateUtils.isOverdue(t.getDueAt())) out.add(t);
        }
        adapter.submitList(out);
    }

    private void filterToday() {
        List<Task> out = new ArrayList<>();
        for (Task t : allTasks) {
            if (DateUtils.isToday(t.getDueAt())) out.add(t);
        }
        adapter.submitList(out);
    }

    private void filterNoDueOnly() {
        List<Task> out = new ArrayList<>();
        for (Task t : allTasks) {
            if (t.getDueAt() == null) out.add(t);
        }
        adapter.submitList(out);
    }

    private void filterTodayPlusNoDue() {
        List<Task> out = new ArrayList<>();
        for (Task t : allTasks) {
            if (t.getDueAt() == null || DateUtils.isToday(t.getDueAt())) out.add(t);
        }
        adapter.submitList(out);
    }

    private void sortByCategory(String catPriority) {
        List<Task> copy = new ArrayList<>(allTasks);
        Collections.sort(copy, (a, b) -> {
            int ga = groupRank(a.getCategory(), catPriority);
            int gb = groupRank(b.getCategory(), catPriority);
            if (ga != gb) return Integer.compare(ga, gb);
            return Long.compare(b.getId(), a.getId()); // newest first within group
        });
        adapter.submitList(copy);
    }

    private int groupRank(String cat, String priority) {
        if (priority.equalsIgnoreCase(cat)) return 0;
        switch (cat) {
            case "Home": return 1;
            case "School": return 2;
            case "Work": return 3;
            default: return 4;
        }
    }

    private void sortByPriority() {
        List<Task> copy = new ArrayList<>(allTasks);
        Collections.sort(copy, new Comparator<Task>() {
            @Override public int compare(Task a, Task b) {
                int pa = a.getPriority();
                int pb = b.getPriority();
                if (pa != pb) return Integer.compare(pa, pb); // High(1) first
                return Long.compare(b.getId(), a.getId());
            }
        });
        adapter.submitList(copy);
    }

    private void sortByDueDate() {
        List<Task> copy = new ArrayList<>(allTasks);
        Collections.sort(copy, (a, b) -> {
            Long da = a.getDueAt();
            Long db = b.getDueAt();
            if (da == null && db == null) return 0;
            if (da == null) return 1; // No due goes last
            if (db == null) return -1;
            int cmp = Long.compare(da, db);
            if (cmp != 0) return cmp;
            return Long.compare(b.getId(), a.getId());
        });
        adapter.submitList(copy);
    }

    private void sortByNewest() {
        List<Task> copy = new ArrayList<>(allTasks);
        Collections.sort(copy, (a, b) -> Long.compare(b.getId(), a.getId()));
        adapter.submitList(copy);
    }
    // endregion

    // region Adapter Callbacks
    @Override
    public void onToggleComplete(Task task, boolean completed) {
        task.setCompleted(completed);
        TaskStorage.save(this, allTasks);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onDelete(Task task) {
        int idx = indexOf(task.getId());
        if (idx >= 0) {
            allTasks.remove(idx);
            TaskStorage.save(this, allTasks);
            applyShowAll();
            Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show();
        }
    }

    private int indexOf(long id) {
        for (int i = 0; i < allTasks.size(); i++) if (allTasks.get(i).getId() == id) return i;
        return -1;
    }
    // endregion
}
