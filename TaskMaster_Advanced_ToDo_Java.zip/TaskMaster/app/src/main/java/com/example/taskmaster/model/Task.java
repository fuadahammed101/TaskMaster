package com.example.taskmaster.model;

import java.util.Objects;

public class Task {
    private long id;
    private String name;
    private String category; // Home | School | Work | None
    private boolean completed;
    private Long dueAt; // epoch millis, nullable
    private int priority; // 1=High,2=Medium,3=Low

    public Task() {}

    public Task(long id, String name, String category, boolean completed, Long dueAt, int priority) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.completed = completed;
        this.dueAt = dueAt;
        this.priority = priority;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }

    public Long getDueAt() { return dueAt; }
    public void setDueAt(Long dueAt) { this.dueAt = dueAt; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Task task = (Task) o;
        return id == task.id;
    }

    @Override public int hashCode() {
        return Objects.hash(id);
    }
}
