package com.example.taskmaster.data;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.taskmaster.model.Task;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class TaskStorage {
    private static final String PREF_NAME = "taskmaster_prefs";
    private static final String KEY_TASKS = "tasks_json";
    private static final Gson gson = new Gson();
    private static final Type LIST_TYPE = new TypeToken<ArrayList<Task>>(){}.getType();

    public static ArrayList<Task> load(Context context) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = sp.getString(KEY_TASKS, null);
        if (json == null || json.isEmpty()) return new ArrayList<>();
        List<Task> list = gson.fromJson(json, LIST_TYPE);
        return new ArrayList<>(list);
    }

    public static void save(Context context, ArrayList<Task> tasks) {
        SharedPreferences sp = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_TASKS, gson.toJson(tasks)).apply();
    }
}
