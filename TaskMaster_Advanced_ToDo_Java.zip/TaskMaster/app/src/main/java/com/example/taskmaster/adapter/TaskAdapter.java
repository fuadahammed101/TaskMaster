package com.example.taskmaster.adapter;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.taskmaster.R;
import com.example.taskmaster.model.Task;
import com.example.taskmaster.util.DateUtils;

import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.VH> {

    public interface Callbacks {
        void onToggleComplete(Task task, boolean completed);
        void onDelete(Task task);
    }

    private final List<Task> data = new ArrayList<>();
    private final Callbacks callbacks;

    public TaskAdapter(Callbacks callbacks) {
        this.callbacks = callbacks;
    }

    public void submitList(List<Task> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        Task t = data.get(pos);
        h.title.setText(t.getName());
        h.category.setText(t.getCategory());
        h.due.setText(DateUtils.formatDate(t.getDueAt()));
        h.priority.setText(priorityText(t.getPriority()));

        h.check.setOnCheckedChangeListener(null);
        h.check.setChecked(t.isCompleted());
        if (t.isCompleted()) {
            h.title.setPaintFlags(h.title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            h.title.setPaintFlags(h.title.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
        }

        h.check.setOnCheckedChangeListener((buttonView, isChecked) -> callbacks.onToggleComplete(t, isChecked));
        h.delete.setOnClickListener(v -> callbacks.onDelete(t));
    }

    @Override public int getItemCount() { return data.size(); }

    private String priorityText(int p) {
        switch (p) {
            case 1: return "High";
            case 2: return "Medium";
            case 3: return "Low";
            default: return "None";
        }
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView title, category, due, priority;
        CheckBox check;
        ImageButton delete;
        VH(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvTaskTitle);
            category = itemView.findViewById(R.id.tvCategory);
            due = itemView.findViewById(R.id.tvDueDate);
            priority = itemView.findViewById(R.id.tvPriority);
            check = itemView.findViewById(R.id.cbDone);
            delete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
