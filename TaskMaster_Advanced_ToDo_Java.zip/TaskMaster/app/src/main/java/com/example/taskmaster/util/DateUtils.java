package com.example.taskmaster.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class DateUtils {
    private static final SimpleDateFormat DATE_FMT = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    public static String formatDate(Long epochMillis) {
        if (epochMillis == null) return "No Date";
        return DATE_FMT.format(new Date(epochMillis));
    }

    public static long toStartOfDayMillis(int year, int monthZeroBased, int day) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, year);
        cal.set(Calendar.MONTH, monthZeroBased);
        cal.set(Calendar.DAY_OF_MONTH, day);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTimeInMillis();
    }

    public static boolean isToday(Long epochMillis) {
        if (epochMillis == null) return false;
        Calendar cal = Calendar.getInstance();
        Calendar today = Calendar.getInstance();
        cal.setTimeInMillis(epochMillis);
        return cal.get(Calendar.ERA) == today.get(Calendar.ERA) &&
               cal.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
               cal.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR);
    }

    public static boolean isOverdue(Long epochMillis) {
        if (epochMillis == null) return false;
        Calendar now = Calendar.getInstance();
        Calendar due = Calendar.getInstance();
        due.setTimeInMillis(epochMillis);
        // Compare at end of today; if due date is before today, it's overdue
        Calendar todayStart = Calendar.getInstance();
        todayStart.set(Calendar.HOUR_OF_DAY, 0);
        todayStart.set(Calendar.MINUTE, 0);
        todayStart.set(Calendar.SECOND, 0);
        todayStart.set(Calendar.MILLISECOND, 0);
        return due.before(todayStart);
    }
}
